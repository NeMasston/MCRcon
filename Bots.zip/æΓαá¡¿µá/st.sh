@ECHO OFF
:server_start
echo.
echo =========================
echo Starting server. OS x32.
echo You need JAVA 8
echo =========================
echo.
java -noverify -Xmx100M -Xms50M  -Dfile.encoding=UTF-8 -jar butty1.jar echo "Butty started"
echo.
echo =========================
echo PRESS CTRL+C TO STOP SERVER
echo =========================
echo.
timeout 5
goto server_start